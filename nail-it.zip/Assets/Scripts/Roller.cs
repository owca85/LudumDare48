﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Roller : MonoBehaviour {

    [SerializeField] private float _angle;
    [SerializeField] private float _duration;

    private float _time;
    
    private void Start() {
        GameEvents.OnPlankMove += Roll;
    }

    private void OnDestroy() {
        GameEvents.OnPlankMove -= Roll;
    }

    private void Update() {
        if (_time > 0) {
            transform.Rotate(Vector3.right, _angle);
            _time -= Time.deltaTime;
        }
    }

    private void Roll() {
        _time = _duration;
    }
}
