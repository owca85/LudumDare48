﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Nail : MonoBehaviour {
    [SerializeField] private NailState _state;
    [SerializeField] private int _hitsLeft;
    [SerializeField] private float _lengthPerHit = 0.4f;
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    
    public bool Hit() {
        transform.Translate(0, -_lengthPerHit, 0);
        _hitsLeft = Mathf.Max(0, _hitsLeft - 1);
        return _hitsLeft == 0;

    }

    public int GetHitsLeft() {
        return _hitsLeft;
    }
}
