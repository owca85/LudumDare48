﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hammer : MonoBehaviour {

    [SerializeField] private Vector3 _slot1Location; 
    [SerializeField] private Vector3 _slot2Location; 
    
    private Animator _animator;
    private Vector3 _targetPostion;
    private NailSlot _currentSlot;

    private ParticleSystem _particleSystem;
    
    private static readonly int HitTrigger = Animator.StringToHash("Hit");

    private void Awake() {
        _animator = GetComponent<Animator>();
        _particleSystem = GetComponentInChildren<ParticleSystem>();
        _targetPostion = transform.position;
        GameEvents.OnNailHit += Hit;
    }

    private void Update() {
        transform.position = Vector3.Lerp(transform.position, _targetPostion, Time.deltaTime * 30);
    }

    private void OnDestroy() {
        GameEvents.OnNailHit -= Hit;
    }

    private void Hit(NailSlot nailSlot) {
        _currentSlot = nailSlot;
        _targetPostion = nailSlot.GetNailLocation() == NailLocation.Slot1 ? _slot1Location : _slot2Location;
        _animator.SetTrigger(HitTrigger);
    }

    private void Impact() {
        if (_currentSlot == null || _currentSlot.GetNail().GetHitsLeft() <= 0) {
            GameEvents.AfterNailProcessed();
        }

        _targetPostion = _slot1Location;
    }

    private void ShowSparks() {
        if (GameState.CurrentComboLevel > 1) {
            _particleSystem.Play();
        }
    }
    
}
