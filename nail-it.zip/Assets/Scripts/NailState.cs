﻿public enum NailState {
    NEW,
    IN_PROGRESS,
    DONE,
}