﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NailSlot : MonoBehaviour {
    
    [SerializeField] private Nail _nail;
    [SerializeField] private Transform _slot1;
    [SerializeField] private Transform _slot2;

    private NailLocation _nailLocation;
    private Movement _movement;

    private void Start() {
        _movement = GetComponent<Movement>();
    }

    public void SetLocation(NailLocation location) {
        _nailLocation = location;
        var slotTransform = GetSlotTransform(location);
        _nail.transform.position = slotTransform.position;
        _nail.transform.parent = slotTransform;
    }

    public NailLocation GetNailLocation() {
        return _nailLocation;
    }

    public void Move(Vector3 offset) {
        _movement.Move(offset);
    }

    public bool Hit() {
        return _nail.Hit();
    }
    
    private Transform GetSlotTransform(NailLocation location) {
        return location == NailLocation.Slot1 ? _slot1 : _slot2;
    }

    public Nail GetNail() {
        return _nail;
    }
    
}
