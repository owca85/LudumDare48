﻿using System.Collections.Generic;
using UnityEngine;

public class GameSettings : MonoBehaviour {

    private static GameSettings _instance;
    
    [SerializeField] private float _nailMovmentSpeed = 1;
    [SerializeField] private float _initialTimeLimit = 10;
    [SerializeField] private float _timeBonusPerHit = .2f;
    
    public static float NailMovmentSpeed => _instance._nailMovmentSpeed;
    public static float InitialTimeLimit => _instance._initialTimeLimit;
    public static float TimeBonusPerHit => _instance._timeBonusPerHit;

    private void Awake() {
        if (_instance == null) {
            _instance = this;
        }
        else {
            Destroy(this);
        }
    }
}