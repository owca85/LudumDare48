﻿using System;

public static class GameEvents {
    public static event Action OnScoreUpdated;
    public static event Action OnGameRestart;
    public static event Action OnGameOver;
    public static event Action<NailSlot> OnNailHit;
    public static event Action OnPlankMove;
    public static event Action OnMiss;
    public static event Action OnAfterNailProcessed;
    public static event Action<int> OnComboUpdate;
    


    public static void GameOver() => OnGameOver?.Invoke();
    public static void RestartGame() => OnGameRestart?.Invoke();
    public static void UpdateScore() => OnScoreUpdated?.Invoke();
    public static void HitNail(NailSlot nailSlot) => OnNailHit?.Invoke(nailSlot);
    public static void MovePlank() => OnPlankMove?.Invoke();
    public static void Miss() => OnMiss?.Invoke();
    public static void AfterNailProcessed() => OnAfterNailProcessed?.Invoke();
    public static void UpdateCombo(int value) => OnComboUpdate?.Invoke(value);

}