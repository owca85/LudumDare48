﻿using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class GameState : MonoBehaviour {
    
    private static GameState _instance;
    
    [SerializeField] private int _score = 0;
    [SerializeField] private float _timeLeft;
    [SerializeField] private bool _isGameOver;
    [SerializeField] private bool _isGameStarted;
    [SerializeField] private int _currentComboLevel;
    
    public static int Score => _instance._score;
    public static float TimeLeft => _instance._timeLeft;
    public static bool IsGameOver => _instance._isGameOver;
    public static bool IsGameStarted => _instance._isGameStarted;
    public static int CurrentComboLevel => _instance._currentComboLevel;

    private const string HighscorePrefKey = "highscore";
    
    private void Awake() {
        if (_instance == null) {
            _instance = this;
        }
        else {
            Destroy(this);
        }
    }

    private void Start() {
        _timeLeft = GameSettings.InitialTimeLimit;
        GameEvents.OnGameOver += GameOver;
    }

    private void OnDestroy() {
        GameEvents.OnGameOver -= GameOver;
    }


    public static void StartGame() {
        _instance._isGameStarted = true;
    }
    
    private void GameOver() {
        _isGameOver = true;
    }

    private void Update() {
        if (!_isGameOver && _isGameStarted) {
            _timeLeft -= Time.deltaTime;
            if (_timeLeft <= 0) {
                _timeLeft = 0;
                _isGameOver = true;
                GameEvents.GameOver();
            }
//            Debug.Log($"Time left: {_timeLeft}");
        }
        
        if ((Input.GetKey(KeyCode.LeftControl) || Input.GetKey(KeyCode.LeftCommand)) 
            && Input.GetKeyDown(KeyCode.H)) {
            _score = 0;
            ClearHighScore();
            GameEvents.UpdateScore();
        }
    }

    public static void UpdateComboLevel(int level) {
        _instance._currentComboLevel = level;
    }
    
    public static void AddScore(int amount) {
        _instance._score += amount;
    }

    public static void AddTime(float amount) {
        _instance._timeLeft = Mathf.Clamp(_instance._timeLeft + amount, 0, GameSettings.InitialTimeLimit);
    }
    
    public static int GetHighScore() {
        return PlayerPrefs.GetInt(HighscorePrefKey, 0);
    }

    private void ClearHighScore() {
        PlayerPrefs.SetInt(HighscorePrefKey, 0);
    }
    
    public static bool UpdateHighScore() {
        var newHighScore = Score > GetHighScore();
        
        if (newHighScore) {
            PlayerPrefs.SetInt(HighscorePrefKey, Score);
        }

        return newHighScore;
    }
}
