﻿public enum NailLocation {
    Slot1,
    Slot2
}