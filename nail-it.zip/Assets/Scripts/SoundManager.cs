﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundManager : MonoBehaviour {
    [SerializeField] private List<AudioClip> _nailHit;
    [SerializeField] private List<AudioClip> _nailAlternative;
    [SerializeField] private List<AudioClip> _failSounds;
    private AudioSource _audioSource;

    void Start() {
        _audioSource = GetComponent<AudioSource>();
        GameEvents.OnNailHit += PlayNailHitSound;
        GameEvents.OnMiss += PlayFailureSound;
    }

    private void OnDestroy() {
        GameEvents.OnNailHit -= PlayNailHitSound;
        GameEvents.OnMiss -= PlayFailureSound;
    }

    void PlayNailHitSound(NailSlot nailSlot) {
        _audioSource.pitch = Random.Range(0.95f, 1.05f);
        _audioSource.volume = Random.Range(0.95f, 1.05f);
        if (nailSlot.GetNail().GetHitsLeft() > 0) {
            _audioSource.PlayOneShot(RandomClip(_nailAlternative));
        }
        else {
            _audioSource.PlayOneShot(RandomClip(_nailHit));
        }
    }

    void PlayFailureSound() {
        _audioSource.pitch = Random.Range(0.95f, 1.05f);
        _audioSource.volume = Random.Range(1.5f, 2f);
        _audioSource.PlayOneShot(RandomClip(_failSounds));
    }

    private AudioClip RandomClip(List<AudioClip> clips) {
        return clips[Random.Range(0, clips.Count)];
    }
}