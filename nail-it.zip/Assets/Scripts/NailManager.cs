﻿using System;
using System.Collections;
using System.Collections.Generic;
using NUnit.Framework.Constraints;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.SceneManagement;
using Random = UnityEngine.Random;

public class NailManager : MonoBehaviour {
    [SerializeField] private GameObject _standardNailSlotPrefab;
    [SerializeField] private GameObject _longNailSlotPrefab;

    [SerializeField] private int _slotCount = 10;
    [SerializeField] private Vector3 _slotOffset = new Vector3(-.25f, 0, 0);

    [SerializeField] private float _plankMoveDelay = 0.5f;
    [SerializeField] private List<Movement> _planks;
    
    //TODO increase chance with time
    [Range(0, 1)] [SerializeField] private float _longNailSpawnChance;

    [SerializeField] private float _comboHitTimeSlot = .2f;
    [SerializeField] private int _maxComboBonusLevel = 20;

    private int _comboCounter = 1;
    private float _lastHitTime;
    

    private List<NailSlot> _activeSlots = new List<NailSlot>();
    private List<NailSlot> _processedSlots = new List<NailSlot>();

    private int _moveCounter = 0;


    private bool _isStarted;


    private void ProcessHit() {
        if (Time.time - _lastHitTime <= _comboHitTimeSlot) {
            _comboCounter++;
        }
        else {
            _comboCounter = 1;
        }

        GameState.UpdateComboLevel(_comboCounter);
        _lastHitTime = Time.time;
    }
    
    private int CalculateHitScore() {
        return (int) (100 * (_maxComboBonusLevel * Math.Tanh((float)_comboCounter /_maxComboBonusLevel)))+1;
//        return 100 * Mathf.Min(_maxComboBonusLevel, _comboCounter);
    }
    
//    private bool _isGameOver;

    // Start is called before the first frame update
    void Start() {
        GameEvents.OnGameRestart += RestatGame;
        GameEvents.OnAfterNailProcessed += MovePlank;
        Init();
    }

    private void OnDestroy() {
        GameEvents.OnGameRestart -= RestatGame;
        GameEvents.OnAfterNailProcessed -= MovePlank;
    }

    // Update is called once per frame
    void Update() {
        if (GameState.IsGameOver) {
            return;
        }

//        //TODO remove this later!!!!!!!!!!!!!!!
//        if (Input.GetKey(KeyCode.LeftControl) && Input.GetKeyDown(KeyCode.Space)) {
//            Hit();
//        }
        
        if (Input.GetKeyDown(KeyCode.LeftArrow) || Input.GetKeyDown(KeyCode.A)) {
            if (GetCurrentSlot().GetNailLocation() == NailLocation.Slot2) {
                Hit();    
            }
            else if (GetCurrentSlot().GetNail().GetHitsLeft() > 0){
                Fail();
            }
            else {
                Debug.Log($"Left 2 Fast");
            }
        }
        else {
            if (Input.GetKeyDown(KeyCode.RightArrow) || Input.GetKeyDown(KeyCode.D)) {
                if (GetCurrentSlot().GetNailLocation() == NailLocation.Slot1) {
                    Hit();    
                }
                else if (GetCurrentSlot().GetNail().GetHitsLeft() > 0){
                    Fail();
                }
                else {
                    Debug.Log($"Right 2 Fast");
                }
            }
        }
    }

    private void Init() {
        for (int i = _slotCount - 1; i >= 0; i--) {
            Spawn(i * _slotOffset.x);
        }
    }

    private void Spawn(float xOffset = 0) {
        var nailSlot = Instantiate(ChooseRandomPrefab(), transform.position + new Vector3(xOffset, 0, 0),
            Quaternion.identity).GetComponent<NailSlot>();
        nailSlot.SetLocation(ChooseNailLocation());
        nailSlot.transform.parent = transform;
        _activeSlots.Add(nailSlot);
    }

    private GameObject ChooseRandomPrefab() {
        return Random.value < _longNailSpawnChance ? _longNailSlotPrefab : _standardNailSlotPrefab;
    }

    private NailLocation ChooseNailLocation() {
        return Random.value < 0.5f ? NailLocation.Slot1 : NailLocation.Slot2;
    }

    private void Hit() {
        if (!_isStarted) {
            GameState.StartGame();
        }
        
        if (_activeSlots[0].GetNail().GetHitsLeft() == 0) {
            Debug.Log($"Too fast, too furious. Skipping hit");
            return;
        }
        bool fullyNailed = _activeSlots[0].Hit();
        GameEvents.HitNail(_activeSlots[0]);
       
        ProcessHit();
//        Debug.Log($"_comboCounter = {_comboCounter}");
        var hitScore = CalculateHitScore();
//        Debug.Log($"hitScore = {hitScore}");
        GameState.AddScore(hitScore);
        GameEvents.UpdateCombo(_comboCounter);
        
        if (!fullyNailed) return;

        
        GameState.AddTime(GameSettings.TimeBonusPerHit);
//        Invoke(nameof(MovePlank), _plankMoveDelay);
        
    }

    private void MovePlank() {
        _processedSlots.Add(_activeSlots[0]);
        _activeSlots.RemoveAt(0);

        _activeSlots.ForEach(s => s.Move(_slotOffset));
        _processedSlots.ForEach(s => s.Move(_slotOffset));
        _planks.ForEach(p => p.Move(_slotOffset));

        _moveCounter++;

        if (_moveCounter % 16 == 0) {
            _planks[0].Teleport(new Vector3(_planks.Count * 4,0,0));
            _planks.Add(_planks[0]);
            _planks.RemoveAt(0);
        }
        
        Spawn();

        if (_processedSlots.Count > 5) {
            Destroy(_processedSlots[0].gameObject);
            _processedSlots.RemoveAt(0);
        }

        GameEvents.UpdateScore();
        GameEvents.MovePlank();
    }

    private void Fail() {
        GameEvents.Miss();
        GameEvents.GameOver();
//        _isGameOver = true;
    }
    
    private NailSlot GetCurrentSlot() {
        return _activeSlots[0];
    }

    //TODO extract to game manager
    public void RestatGame() {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
}