﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour
{
    
    private Vector3 _targetPosition;

    void Start() {
        _targetPosition = transform.position;
    }

    void Update() {
        transform.position = Vector3.Lerp(transform.position, _targetPosition, GameSettings.NailMovmentSpeed * Time.deltaTime);
    }
    
    public void Move(Vector3 offset) {
        _targetPosition = _targetPosition + offset;
    }
    
    public void Teleport(Vector3 offset) {
        Move(offset);
        transform.position = _targetPosition;
    }
}
