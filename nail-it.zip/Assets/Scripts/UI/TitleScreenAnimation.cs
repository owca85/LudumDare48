﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class TitleScreenAnimation : MonoBehaviour {

    [SerializeField] private Image _fadeInImage;
    [SerializeField] private AudioClip _hitSound;
    private AudioSource _audioSource;
    private Animator _animator;
   
    
    void Start() {
        _audioSource = GetComponent<AudioSource>();
        _animator = GetComponent<Animator>();
        _fadeInImage.color = Color.black;
    }

    private void Update() {
        _fadeInImage.color = new Color(0,0,0,_fadeInImage.color.a - Time.deltaTime * 1);
        if (Input.anyKeyDown) {
            _animator.SetTrigger("TitleHit");
        }
    }

    public void PlayHitSound(){
       _audioSource.PlayOneShot(_hitSound);
    }

    public void StartGame() {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }

}
