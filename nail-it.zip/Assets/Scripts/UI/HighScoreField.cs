﻿using TMPro;
using UnityEngine;

public class HighScoreField : MonoBehaviour {
    
    private TextMeshProUGUI _text;
    private int _initialHighScore;
    
    void Awake() {
        _text = GetComponent<TextMeshProUGUI>();
        GameEvents.OnScoreUpdated += UpdateValue;
    }

    private void Start() {
        _initialHighScore = GameState.GetHighScore();
        UpdateValue();
    }

    private void OnDestroy() {
        GameEvents.OnScoreUpdated -= UpdateValue;
    }

    private void UpdateValue() {
        var score = GameState.Score;
        var currentHighScore = _initialHighScore > score ? _initialHighScore : score;
        _text.text = currentHighScore.ToString();
    }
}
