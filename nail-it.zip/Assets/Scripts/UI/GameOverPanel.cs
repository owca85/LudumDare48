﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameOverPanel : MonoBehaviour {
    [SerializeField] private GameObject _panel;
    [SerializeField] private GameObject _finalScoreLabel;
    [SerializeField] private GameObject _highScoreLabel;

    private CanvasGroup _panelCanvasGroup;
    
    void Start() {
        GameEvents.OnGameOver += Show;
        _panel.SetActive(false);
        _panelCanvasGroup = _panel.GetComponent<CanvasGroup>();
    }

    private void OnDestroy() {
        GameEvents.OnGameOver -= Show;
    }

    private void Update() {
        if (_panel.activeSelf) {
            _panelCanvasGroup.alpha = Mathf.Min(1, _panelCanvasGroup.alpha + Time.deltaTime);
        }
        
        if (_panel.activeSelf && 
            (Input.GetKeyDown(KeyCode.Space) 
            || Input.GetKeyDown(KeyCode.Escape)
            || Input.GetKeyDown(KeyCode.Return))) {
            RestartGame();
        }
    }

    void RestartGame() {
        GameEvents.RestartGame();
    }
    
    void Show() {
        _panelCanvasGroup.alpha = 0;
        _panel.SetActive(true);
        GameEvents.UpdateScore();
        var isNewHighScore = GameState.UpdateHighScore();
        _highScoreLabel.SetActive(isNewHighScore);
        _finalScoreLabel.SetActive(!isNewHighScore);
    }
    
    
}
