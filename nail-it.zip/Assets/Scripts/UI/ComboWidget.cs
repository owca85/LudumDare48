﻿using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.PlayerLoop;

public class ComboWidget : MonoBehaviour {

    [SerializeField] private float _bounceDuration;
    [SerializeField] private float _bounceAmount;
    
    private TextMeshProUGUI _textMesh;
    [SerializeField] private TextMeshProUGUI _label;

    private float _timer;
    private Vector3 _initialScale;
     
    void Start() {
        _textMesh = GetComponent<TextMeshProUGUI>();
        _initialScale = transform.localScale;
        GameEvents.OnComboUpdate += UpdateCombo;
        UpdateCombo(1);
    }

    private void OnDestroy() {
        GameEvents.OnComboUpdate -= UpdateCombo;
    }

    
    void UpdateCombo(int value) {
        _textMesh.text = value > 1 ? "x" + value : "";
        _label.text = value > 1 ? "COMBO" : "";
        _timer = _bounceDuration;
    }
    
    void Update()
    {
        
        if (_timer > 0) {
            var newScale = _initialScale * (1 + (_bounceAmount * Mathf.Sin(Mathf.PI * (_bounceDuration - _timer) / _bounceDuration)));
            transform.localScale = newScale; 
            _timer -= Time.deltaTime;
        }
        else {
            transform.localScale = _initialScale;
        }
    }
}
