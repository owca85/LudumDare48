﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

public class Desaturate : MonoBehaviour {

    [SerializeField] private float _timeLeftTreshold = 0.25f; 
    private Volume _volume;
    private ColorAdjustments _colorAdjustments;

    // Start is called before the first frame update
    void Start() {
        _volume = GetComponent<Volume>();
        _volume.profile.TryGet<ColorAdjustments>(out _colorAdjustments);
    }

    // Update is called once per frame
    void Update() {
        if (_colorAdjustments != null) {
            var timeLeft = GameState.TimeLeft / GameSettings.InitialTimeLimit;
            if (timeLeft < _timeLeftTreshold) {
                var saturation = ((_timeLeftTreshold - timeLeft)/_timeLeftTreshold) * -100;
                _colorAdjustments.saturation.value = saturation;
            }
        }
    }
}