﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraShaker : MonoBehaviour
{
    private static CameraShaker _instance;
    
    [SerializeField] private float _damping = 1;
    [SerializeField] private float _aplitude = 1;
    [SerializeField] private float _duration = 1;
    
//    public static int Score => _instance._score;

    private Vector3 _initialCameraPosition;
    private float _timeLeft;
    private float _currentAmplitude;
    
    private void Awake() {
        if (_instance == null) {
            _instance = this;
        }
        else {
            Destroy(this);
        }

        _initialCameraPosition = Camera.main.transform.position;
    }

    private void Update() {
        if (Input.GetKeyDown(KeyCode.S)) {
            Shake(.05f,0.01f);
        }
        
        if (_timeLeft > 0) {
            var randomPosition = _initialCameraPosition + (Random.insideUnitSphere.normalized * _currentAmplitude);
            Camera.main.transform.position = new Vector3(0, randomPosition.y, randomPosition.z);
            
            _currentAmplitude = Mathf.Max(0, _currentAmplitude - Time.deltaTime * _damping);
            _timeLeft -= Time.deltaTime;
        }
        else {
            Camera.main.transform.position = _initialCameraPosition;
        }
    }

    public static void Shake(float duration, float amplitude) {
//        _instance._timeLeft = duration;
//        _instance._currentAmplitude = amplitude;
        _instance._timeLeft = _instance._duration;
        _instance._currentAmplitude = _instance._aplitude;
    }
}
