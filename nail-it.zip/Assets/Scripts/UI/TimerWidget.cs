﻿using UnityEngine;
using UnityEngine.UI;

public class TimerWidget : MonoBehaviour {
    [Range(0, 4f)] [SerializeField] private float _shakeAmount;
    [SerializeField] private Image _image;

    private Vector3? _initialPosition;

    // Update is called once per frame
    void Update() {
        if (!GameState.IsGameStarted) {
            return;
        }
        var timeLeft = GameState.TimeLeft / GameSettings.InitialTimeLimit;
        _image.fillAmount = timeLeft;
        if (timeLeft < 0.25 && timeLeft > 0) {
            if (_initialPosition == null) {
                _initialPosition = transform.position;
            }
            transform.position = _initialPosition.Value + Random.insideUnitSphere.normalized * _shakeAmount;
        }
        else if (_initialPosition != null){
            transform.position = _initialPosition.Value;
        }
    }
}