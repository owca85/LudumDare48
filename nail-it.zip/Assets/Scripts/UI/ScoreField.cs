﻿using TMPro;
using UnityEngine;

public class ScoreField : MonoBehaviour {
    
    private TextMeshProUGUI _text;
    // Start is called before the first frame update
    void Awake() {
        _text = GetComponent<TextMeshProUGUI>();
        GameEvents.OnScoreUpdated += UpdateValue;
    }

    private void Start() {
        UpdateValue();
    }

//    private void OnEnable() {
//        UpdateValue();
//    }

    private void OnDestroy() {
        GameEvents.OnScoreUpdated -= UpdateValue;
    }

    private void UpdateValue() {
        _text.text = GameState.Score.ToString();
    }
}
