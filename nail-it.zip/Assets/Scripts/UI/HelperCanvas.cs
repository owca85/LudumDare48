﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HelperCanvas : MonoBehaviour {

    [SerializeField] private float _fadeSpeed;
    private CanvasGroup _canvasGroup;
    private Movement _movement;
    
    
    void Start() {
        _canvasGroup = GetComponent<CanvasGroup>();
        _movement = GetComponent<Movement>();
        GameEvents.OnPlankMove += Move;
    }

    private void OnDestroy() {
        GameEvents.OnPlankMove += Move;
    }

    private void Move() {
        _movement.Move(new Vector3(-.25f, 0, 0));
    }
    
    // Update is called once per frame
    void Update()
    {
        if (GameState.IsGameStarted) {
            _canvasGroup.alpha = Mathf.Max(0, _canvasGroup.alpha - Time.deltaTime * _fadeSpeed);
        }

        if (_canvasGroup.alpha <= 0) {
            gameObject.SetActive(false);
        }
    }
}
